module.exports = {
  silent: false,
  collectCoverage: true,
  testEnvironment: 'node',
  setupFiles: ['dotenv/config'],
};
